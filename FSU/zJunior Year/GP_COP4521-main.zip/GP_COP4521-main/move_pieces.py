class WhitePawn:
    def __init__(self,Board,start,to):
        self.Board=Board
        self.start=start
        self.to=to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.Board[x1][y1] == 'WP' and x2 == x1 - 1 and y2 == y1 and self.Board[x2][y2] == '. ':
            return True

        elif self.Board[x1][y1] == 'WP' and x2 == x1 - 1 and (y2 == y1 - 1 or y2 == y1 + 1) and (
                self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or
                self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP'):
            return True
        elif self.Board[x1][y1] == 'WP' and x2 == x1 - 2 and y2 == y1 and self.Board[x2][y2] == '. ' and self.Board[x1 - 1][y1] == '. ' and x1 == 6:
            return True
        else:
            return False

class WhiteRook():
    def __init__(self, Board, start, to):
        self.Board = Board
        self.start = start
        self.to = to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.Board[x1][y1] == 'WR':
            if x2 < 8 and y2 < 8:
                if x2 == x1:
                    if y2 > y1:
                        diff = y2 - y1
                        for i in range(1,diff):
                            if self.Board[x2][y1+i] != '. ' :
                                return False
                        if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP': 
                            return False
                        return True

                    elif y1 > y2:
                        diff = y1 - y2
                        for i in range(1,diff):
                            if self.Board[x2][y1-i] != '. ':
                                return False
                        if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP': 
                            return False
                        return True
                elif y2 == y1:
                    if x2 > x1:
                        diff = x2 - x1
                        for i in range(1,diff):
                            if self.Board[x1+i][y2] != '. ':
                                return False
                        if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP': 
                            return False
                        return True

                    elif x1 > x2:
                        diff = x1 - x2
                        for i in range(1,diff):
                            if self.Board[x1-i][y2] != '. ':
                                return False
                        if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP': 
                            return False
                        return True
                return False

class WhiteKnight():
    def __init__(self, Board, start, to):
        self.Board = Board
        self.start = start
        self.to = to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.Board[x1][y1] == 'WN':
            if x2 < 8 and y2 < 8:
                if self.Board[x2][y2]!='WP' and self.Board[x2][y2]!='WR' and self.Board[x2][y2]!='WN' and self.Board[x2][y2]!='WB' and self.Board[x2][y2]!='WQ' and self.Board[x2][y2]!='WK':
                    if x2==x1-2 and y2==y1-1:
                        return True
                    elif x2==x1-2 and y2==y1+1:
                        return True
                    elif x2==x1+1 and y2==y1+2:
                        return True
                    elif x2==x1+1 and y2==y1-2:
                        return True
                    elif x2==x1-1 and y2==y1-2:
                        return True
                    elif x2==x1-1 and y2==y1+2:
                        return True
                    elif x2==x1+2 and y2==y1-1:
                        return True
                    elif x2==x1+2 and y2==y1+1:
                        return True
                    else:
                        return False
        return False


class WhiteBishop():
    def __init__(self, Board, start, to):
        self.Board = Board
        self.start = start
        self.to = to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.Board[x1][y1] == 'WB':
            if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP':
                return False

            if x2 < 8 and y2 < 8:
                for n in range(8):
                    if (x2==x1+n and y2==y1+n):
                        for i in range(1,n):
                            if self.Board[x1+i][y1+i] != '. ':
                                return False
                        return True
                    elif (x2==x1-n and y2==y1+n):
                        for i in range(1,n):
                            if self.Board[x1-i][y1+i] != '. ':
                                return False
                        return True
                    elif (x2==x1-n and y2==y1-n):
                        for i in range(1,n):
                            if self.Board[x1-i][y1-i] != '. ':
                                return False
                        return True
                    elif (x2==x1+n and y2==y1-n):
                        for i in range(1,n):
                            if self.Board[x1+i][y1-i] != '. ':
                                return False
                        return True

                return False


class WhiteQueen():
    def __init__(self, Board, start, to):
        self.Board = Board
        self.start = start
        self.to = to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.Board[x1][y1] == 'WQ':
            if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP':
                return False

            if x2 < 8 and y2 < 8:
                for n in range(8):
                    if (x2==x1+n and y2==y1+n):
                        for i in range(1,n):
                            if self.Board[x1+i][y1+i] != '. ':
                                return False
                        return True
                    elif (x2==x1-n and y2==y1+n):
                        for i in range(1,n):
                            if self.Board[x1-i][y1+i] != '. ':
                                return False
                        return True
                    elif (x2==x1-n and y2==y1-n):
                        for i in range(1,n):
                            if self.Board[x1-i][y1-i] != '. ':
                                return False
                        return True
                    elif (x2==x1+n and y2==y1-n):
                        for i in range(1,n):
                            if self.Board[x1+i][y1-i] != '. ':
                                return False
                        return True

                if x2 == x1:
                    if y2 > y1:
                        diff = y2 - y1
                        for i in range(1,diff):
                            if self.Board[x2][y1+i] != '. ' :
                                return False
                        if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP': 
                            return False
                        return True

                    elif y1 > y2:
                        diff = y1 - y2
                        for i in range(1,diff):
                            if self.Board[x2][y1-i] != '. ':
                                return False
                        if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP': 
                            return False
                        return True
                elif y2 == y1:
                    if x2 > x1:
                        diff = x2 - x1
                        for i in range(1,diff):
                            if self.Board[x1+i][y2] != '. ':
                                return False
                        if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP': 
                            return False
                        return True

                    elif x1 > x2:
                        diff = x1 - x2
                        for i in range(1,diff):
                            if self.Board[x1-i][y2] != '. ':
                                return False
                        if self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP': 
                            return False
                        return True
            return False

class WhiteKing():
    def __init__(self, Board, start, to):
        self.Board = Board
        self.start = start
        self.to = to

    def can_castle(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == 7 and y2 == 2 and self.Board[x1][y1] == 'WK' and self.Board[7][0] == 'WR' and self.Board[7][
            3] == '. ' and self.Board[7][2] == '. ' and self.Board[7][1] == '. ':
            return True
        elif x2 == 7 and y2 == 6 and self.Board[x1][y1] == 'WK' and self.Board[7][7] == 'WR' and self.Board[7][
            5] == '. ' and self.Board[7][6] == '. ':
            return True

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.can_castle()==True:
            return True

        if self.Board[x1][y1] == 'WK':
            if x2 < 8 and y2 < 8:
                if ((x2==x1+1 and y2==y1+1) or (x2==x1-1 and y2==y1-1) or (x2==x1+1 and y2==y1-1) or (x2==x1-1 and y2==y1+1)) and (self.Board[x2][y2] != 'WR' and self.Board[x2][y2] != 'WB' and self.Board[x2][y2] != 'WN' and self.Board[x2][y2] != 'WQ' and self.Board[x2][y2] != 'WK' and self.Board[x2][y2] != 'WP'):
                    return True
                elif ((x2==x1+1 and y2==y1) or (x2==x1-1 and y2==y1) or (x2==x1 and y2==y1+1) or (x2==x1 and y2==y1-1)) and (self.Board[x2][y2] != 'WR' and self.Board[x2][y2] != 'WB' and self.Board[x2][y2] != 'WN' and self.Board[x2][y2] != 'WQ' and self.Board[x2][y2] != 'WK' and self.Board[x2][y2] != 'WP'):
                    return True

                return False
        else:
            return False


class BlackPawn():
    def __init__(self,Board,start,to):
        self.Board=Board
        self.start=start
        self.to=to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.Board[x1][y1] == 'BP' and x2 == x1 + 1 and y2 == y1 and self.Board[x2][y2] == '. ':
            return True

        elif self.Board[x1][y1] == 'BP' and x2 == x1 + 1 and (y2 == y1 - 1 or y2 == y1 + 1) and (
                self.Board[x2][y2] == 'WR' or self.Board[x2][y2] == 'WB' or self.Board[x2][y2] == 'WN' or self.Board[x2][y2] == 'WQ' or
                self.Board[x2][y2] == 'WK' or self.Board[x2][y2] == 'WP'):
            return True
        elif self.Board[x1][y1] == 'BP' and x2 == x1 + 2 and y2 == y1 and self.Board[x2][y2] == '. ' and self.Board[x1 + 1][y1] == '. ' and x1 == 1:
            return True
        else:
            return False

class BlackRook():
    def __init__(self,Board,start,to):
        self.Board=Board
        self.start=start
        self.to=to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.Board[x1][y1] == 'BR':
            if x2 < 8 and y2 < 8:
                if x2 == x1:
                    if y2 > y1:
                        diff = y2 - y1
                        for i in range(1,diff):
                            if self.Board[x2][y1+i] != '. ' :
                                return False
                        if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP': 
                            return False
                        return True

                    elif y1 > y2:
                        diff = y1 - y2
                        for i in range(1,diff):
                            if self.Board[x2][y1-i] != '. ':
                                return False
                        if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP': 
                            return False
                        return True
                elif y2 == y1:
                    if x2 > x1:
                        diff = x2 - x1
                        for i in range(1,diff):
                            if self.Board[x1+i][y2] != '. ':
                                return False
                        if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP': 
                            return False
                        return True

                    elif x1 > x2:
                        diff = x1 - x2
                        for i in range(1,diff):
                            if self.Board[x1-i][y2] != '. ':
                                return False
                        if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP': 
                            return False
                        return True
                return False

class BlackKnight():
    def __init__(self, Board, start, to):
        self.Board = Board
        self.start = start
        self.to = to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.Board[x1][y1] == 'BN':
            if x2 < 8 and y2 < 8:
                if self.Board[x2][y2]!='BP' and self.Board[x2][y2]!='BR' and self.Board[x2][y2]!='BN' and self.Board[x2][y2]!='BB' and self.Board[x2][y2]!='BQ' and self.Board[x2][y2]!='BK':
                    if x2==x1-2 and y2==y1-1:
                        return True
                    elif x2==x1-2 and y2==y1+1:
                        return True
                    elif x2==x1+1 and y2==y1+2:
                        return True
                    elif x2==x1+1 and y2==y1-2:
                        return True
                    elif x2==x1-1 and y2==y1-2:
                        return True
                    elif x2==x1-1 and y2==y1+2:
                        return True
                    elif x2==x1+2 and y2==y1-1:
                        return True
                    elif x2==x1+2 and y2==y1+1:
                        return True
                    else:
                        return False
        return False

class BlackBishop():
    def __init__(self, Board, start, to):
        self.Board = Board
        self.start = start
        self.to = to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.Board[x1][y1] == 'BB':
            if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP':
                return False

            if x2 < 8 and y2 < 8:
                for n in range(8):
                    if (x2==x1+n and y2==y1+n):
                        for i in range(1,n):
                            if self.Board[x1+i][y1+i] != '. ':
                                return False
                        return True
                    elif (x2==x1-n and y2==y1+n):
                        for i in range(1,n):
                            if self.Board[x1-i][y1+i] != '. ':
                                return False
                        return True
                    elif (x2==x1-n and y2==y1-n):
                        for i in range(1,n):
                            if self.Board[x1-i][y1-i] != '. ':
                                return False
                        return True
                    elif (x2==x1+n and y2==y1-n):
                        for i in range(1,n):
                            if self.Board[x1+i][y1-i] != '. ':
                                return False
                        return True

                return False

class BlackQueen():
    def __init__(self, Board, start, to):
        self.Board = Board
        self.start = start
        self.to = to

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False
        
        if self.Board[x1][y1] == 'BQ':
            if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP':
                return False

            if x2 < 8 and y2 < 8:
                for n in range(8):
                    if (x2==x1+n and y2==y1+n):
                        for i in range(1,n):
                            if self.Board[x1+i][y1+i] != '. ':
                                return False
                        return True
                    elif (x2==x1-n and y2==y1+n):
                        for i in range(1,n):
                            if self.Board[x1-i][y1+i] != '. ':
                                return False
                        return True
                    elif (x2==x1-n and y2==y1-n):
                        for i in range(1,n):
                            if self.Board[x1-i][y1-i] != '. ':
                                return False
                        return True
                    elif (x2==x1+n and y2==y1-n):
                        for i in range(1,n):
                            if self.Board[x1+i][y1-i] != '. ':
                                return False
                        return True

                if x2 == x1:
                    if y2 > y1:
                        diff = y2 - y1
                        for i in range(1,diff):
                            if self.Board[x2][y1+i] != '. ' :
                                return False
                        if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP': 
                            return False
                        return True

                    elif y1 > y2:
                        diff = y1 - y2
                        for i in range(1,diff):
                            if self.Board[x2][y1-i] != '. ':
                                return False
                        if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP': 
                            return False
                        return True
                elif y2 == y1:
                    if x2 > x1:
                        diff = x2 - x1
                        for i in range(1,diff):
                            if self.Board[x1+i][y2] != '. ':
                                return False
                        if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP': 
                            return False
                        return True

                    elif x1 > x2:
                        diff = x1 - x2
                        for i in range(1,diff):
                            if self.Board[x1-i][y2] != '. ':
                                return False
                        if self.Board[x2][y2] == 'BR' or self.Board[x2][y2] == 'BB' or self.Board[x2][y2] == 'BN' or self.Board[x2][y2] == 'BQ' or self.Board[x2][y2] == 'BK' or self.Board[x2][y2] == 'BP': 
                            return False
                        return True
            return False

class BlackKing():
    def __init__(self, Board, start, to):
        self.Board = Board
        self.start = start
        self.to = to

    def can_castle(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == 7 and y2 == 2 and self.Board[x1][y1] == 'BK' and self.Board[7][0] == 'BR' and self.Board[7][
            3] == '. ' and self.Board[7][2] == '. ' and self.Board[7][1] == '. ':
            return True
        elif x2 == 7 and y2 == 6 and self.Board[x1][y1] == 'BK' and self.Board[7][7] == 'BR' and self.Board[7][
            5] == '. ' and self.Board[7][6] == '. ':
            return True

    def move(self):
        y1, x1 = self.start
        y2, x2 = self.to

        if x2 == x1 and y2 == y1:
            return False

        if self.can_castle()==True:
            return True

        if self.Board[x1][y1] == 'BK':
            if x2 < 8 and y2 < 8:
                if ((x2==x1+1 and y2==y1+1) or (x2==x1-1 and y2==y1-1) or (x2==x1+1 and y2==y1-1) or (x2==x1-1 and y2==y1+1)) and (self.Board[x2][y2] != 'BR' and self.Board[x2][y2] != 'BB' and self.Board[x2][y2] != 'BN' and self.Board[x2][y2] != 'BQ' and self.Board[x2][y2] != 'BK' and self.Board[x2][y2] != 'BP'):
                    return True
                elif ((x2==x1+1 and y2==y1) or (x2==x1-1 and y2==y1) or (x2==x1 and y2==y1+1) or (x2==x1 and y2==y1-1)) and (self.Board[x2][y2] != 'BR' and self.Board[x2][y2] != 'BB' and self.Board[x2][y2] != 'BN' and self.Board[x2][y2] != 'BQ' and self.Board[x2][y2] != 'BK' and self.Board[x2][y2] != 'BP'):
                    return True

                return False
        else:
            return False
