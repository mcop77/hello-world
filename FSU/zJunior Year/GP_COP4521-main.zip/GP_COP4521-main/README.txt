# GP_COP4521

Group Members:
Marshall Copeland, Modibo Traore

GitHub Repository Link:
https://github.com/JoeSchmitt-2/GP_COP4521.git

Video Link:
https://youtu.be/Pj5BN905OZs


Description:
Our group project for this semester was recreating the game Chess. In the game, there are black and white pieces that interact with each other, with each piece having different moving capabilities. The game is played until a king piece is taken by the opponent’s piece, which is called checkmate. We decided to choose this game because we are passionate about the game of chess and how it is played.

Details:
In this project we use a Pygame GUI to show the pieces on the board and how they move. The White pieces move first at the start of the game, and then the black pieces are able to be moved as the game alternates between each player. All you need to do to move a piece is click the square it is in and drag it to where you want it. If the move is illegal, that piece will not be moved, and it will still be your turn to move a piece. At the end after the opponent or your King is taken resulting in checkmate, the terminal asks you if you would like to play again. If yes, type out "yes", and the board will reset, and the game can be played again. Anything other than typing "yes" will result in the program quitting. The images for the program are stored in an "images" folder, which is located where the 2 files that we are submitting, move_pieces.py and ImagePrint.py, where move_pieces is imported in to ImagePrint. 

Python Libraries:
Pygame

Resources: 
We do not have any other resources. 

Features:
None beyond the initial project proposal 

Separation of Work:
Our group had 3 group members at the beginning of the semester, however Joseph Schmitt abandoned us for unknown reasons at the start of October. We have tried to make contact with him to make sure that he was able to do his assigned work for the project, however he never responded to any of those messages. That has left us as a group with only 2 members, Modibo Traore and Marshall Copeland, for the majority of the time we have been working on this project. We have no idea what happened to him, and no idea if he is even in this class anymore. Due to that, the separation of work has been 50/50. Marshall was tasked with initializing the board when it is set up and getting the GUI to reflect what is happening in the game. Modibo was responsible for the logic of the pieces moving and making sure that each move is allowed in the game. This project was very difficult to complete with only 2 group members. It got to the point where we needed to meet every day of the week for some of the weeks just to make sure that this project would get done by the time it was due.
