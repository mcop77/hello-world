import pygame
import move_pieces

def driver():
    pygame.init()

    window = pygame.display.set_mode((489,489))
    pygame.display.set_caption('Chess')

    board = pygame.image.load('images/board.png').convert_alpha()

    WK = pygame.image.load('images/wk.png').convert_alpha()
    BK = pygame.image.load('images/bk.png').convert_alpha()
    WN = pygame.image.load('images/wn.png').convert_alpha()
    BN = pygame.image.load('images/bn.png').convert_alpha()
    WR = pygame.image.load('images/wr.png').convert_alpha()
    BR = pygame.image.load('images/br.png').convert_alpha()
    WQ = pygame.image.load('images/wq.png').convert_alpha()
    BQ = pygame.image.load('images/bq.png').convert_alpha()
    WB = pygame.image.load('images/wb.png').convert_alpha()
    BB = pygame.image.load('images/bb.png').convert_alpha()
    WP = pygame.image.load('images/wp.png').convert_alpha()
    BP = pygame.image.load('images/bp.png').convert_alpha()

    # sets up backend grid
    row = 8
    col = 8

    Board = []

    for x in range(8):
        board_y = []
        for y in range(8):
            board_y.append('. ')
        Board.append(board_y)

    Board[0][0] = 'BR'
    Board[0][1] = 'BB'
    Board[0][2] = 'BN'
    Board[0][3] = 'BQ'
    Board[0][4] = 'BK'
    Board[0][5] = 'BN'
    Board[0][6] = 'BB'
    Board[0][7] = 'BR'

    # for loop for pawns
    for i in range(0,8):
        Board[1][i] = 'BP'

    # for loop for spaces
    for i in range(2,6):
        for j in range(0,8):
            Board[i][j] = '. '

    # for loop for pawns
    for i in range(0,8):
        Board[6][i] = 'WP'

    Board[7][0] = 'WR'
    Board[7][1] = 'WB'
    Board[7][2] = 'WN'
    Board[7][3] = 'WQ'
    Board[7][4] = 'WK'
    Board[7][5] = 'WN'
    Board[7][6] = 'WB'
    Board[7][7] = 'WR'

    updateBoard(Board, window)
    pygame.display.update()  

    turn = 0 
    gameOver = False

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                pos = (0,0)
                pos2 = (0,0)

                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()

                    pos = list(pos)

                    pos[0] = int(pos[0] / 61)
                    pos[1] = int(pos[1] / 61)

                    pos = tuple(pos)
                
                    y1, x1 = pos

                if event.type == pygame.MOUSEBUTTONUP:
                    pos2 = pygame.mouse.get_pos()

                    pos2 = list(pos2)

                    pos2[0] = int(pos2[0] / 61)
                    pos2[1] = int(pos2[1] / 61)

                    pos2 = tuple(pos2)

                    pos = list(pos)

                    pos[0] = y1
                    pos[1] = x1

                    pos = tuple(pos)
                
                    y2, x2 = pos2

                    if Board[x1][y1] == 'WP' and (turn + 2) % 2 == 0:
                        if move_pieces.WhitePawn(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'BK' and x2 == 0:
                                Board[x2][y2] = 'WQ'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WQ, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True

                            elif Board[x2][y2] == 'BK':
                                Board[x2][y2] = 'WP'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WP, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True
                                
                            elif x2 == 0:
                                Board[x2][y2] = 'WQ'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WQ, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1

                            else:
                                Board[x2][y2] = 'WP'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WP, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1                            

                    elif Board[x1][y1] == 'WR' and (turn + 2) % 2 == 0:
                        if move_pieces.WhiteRook(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'BK':
                                Board[x2][y2] = 'WR'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WR, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True
                                
                            else:
                                Board[x2][y2] = 'WR'
                                Board[x1][y1] = '. '
                                window.blit(WR, (y2 * 61 + 1, x2 * 61 + 1))
                                updateBoard(Board, window)
                                pygame.display.update()
                                turn += 1
                            

                    elif Board[x1][y1] == 'WB' and (turn + 2) % 2 == 0:
                        if move_pieces.WhiteBishop(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'BK':
                                Board[x2][y2] = 'WB'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WB, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True
                            
                            else:
                                Board[x2][y2] = 'WB'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WB, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()  
                                turn += 1
                            

                    elif Board[x1][y1] == 'WN' and (turn + 2) % 2 == 0:
                        if move_pieces.WhiteKnight(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'BK':
                                Board[x2][y2] = 'WN'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WN, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True

                            else:
                                Board[x2][y2] = 'WN'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WN, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1
                            

                    elif Board[x1][y1] == 'WQ' and (turn + 2) % 2 == 0:
                        if move_pieces.WhiteQueen(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'BK':
                                Board[x2][y2] = 'WQ'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WQ, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True
                            
                            else:
                                Board[x2][y2] = 'WQ'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WQ, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1
                            

                    elif Board[x1][y1] == 'WK' and (turn + 2) % 2 == 0:
                        if move_pieces.WhiteKing(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'BK':
                                Board[x2][y2] = 'WK'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WK, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True

                            else:
                                Board[x2][y2] = 'WK'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(WK, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1
                            

                    elif Board[x1][y1] == 'BP' and (turn + 2) % 2 == 1:
                        if move_pieces.BlackPawn(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'WK' and x2 == 0:
                                Board[x2][y2] = 'BQ'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BQ, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True

                            elif Board[x2][y2] == 'WK':
                                Board[x2][y2] = 'BP'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BP, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True
                                
                            elif x2 == 0:
                                Board[x2][y2] = 'BQ'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BQ, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1

                            else:
                                Board[x2][y2] = 'BP'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BP, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1 

                    elif Board[x1][y1] == 'BR' and (turn + 2) % 2 == 1:
                        if move_pieces.BlackRook(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'WK':
                                Board[x2][y2] = 'BR'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BR, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True

                            else:
                                Board[x2][y2] = 'BR'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BR, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1
                            

                    elif Board[x1][y1] == 'BB' and (turn + 2) % 2 == 1:
                        if move_pieces.BlackBishop(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'WK':
                                Board[x2][y2] = 'BB'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BB, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True

                            else:
                                Board[x2][y2] = 'BB'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BB, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1
                            

                    elif Board[x1][y1] == 'BN' and (turn + 2) % 2 == 1:
                        if move_pieces.BlackKnight(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'WK':
                                Board[x2][y2] = 'BN'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BN, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True

                            else:
                                Board[x2][y2] = 'BN'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BN, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1
                            

                    elif Board[x1][y1] == 'BQ' and (turn + 2) % 2 == 1:
                        if move_pieces.BlackQueen(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'WK':
                                Board[x2][y2] = 'BQ'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BQ, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True

                            else:
                                Board[x2][y2] = 'BQ'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BQ, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1
                            

                    elif Board[x1][y1] == 'BK' and (turn + 2) % 2 == 1:
                        if move_pieces.BlackKing(Board, pos, pos2).move() == True:
                            if Board[x2][y2] == 'WK':
                                Board[x2][y2] = 'BK'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BK, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                print("GAME OVER!")
                                gameOver = True                           
 
                            else:
                                Board[x2][y2] = 'BK'
                                Board[x1][y1] = '. '
                                updateBoard(Board, window)
                                window.blit(BK, (y2 * 61 + 1, x2 * 61 + 1))
                                pygame.display.update()
                                turn += 1
                            


                    if gameOver == True:
                        choice = input("Would you like to play again? ")  

                        if choice == "yes":
                            gameOver = False
                            turn = 0

                            for x in range(8):
                                board_y = []
                                for y in range(8):
                                    board_y.append('. ')
                                Board.append(board_y)

                            Board[0][0] = 'BR'
                            Board[0][1] = 'BB'
                            Board[0][2] = 'BN'
                            Board[0][3] = 'BQ'
                            Board[0][4] = 'BK'
                            Board[0][5] = 'BN'
                            Board[0][6] = 'BB'
                            Board[0][7] = 'BR'

                            # for loop for pawns
                            for i in range(0,8):
                                Board[1][i] = 'BP'

                            # for loop for spaces
                            for i in range(2,6):
                                for j in range(0,8):
                                    Board[i][j] = '. '

                            # for loop for pawns
                            for i in range(0,8):
                                Board[6][i] = 'WP'

                            Board[7][0] = 'WR'
                            Board[7][1] = 'WB'
                            Board[7][2] = 'WN'
                            Board[7][3] = 'WQ'
                            Board[7][4] = 'WK'
                            Board[7][5] = 'WN'
                            Board[7][6] = 'WB'
                            Board[7][7] = 'WR'

                            updateBoard(Board, window)
                            pygame.display.update()

                        else:
                            running = False

def updateBoard(Board, window):
    window.fill((0,0,0))

    board = pygame.image.load('images/board.png').convert_alpha()

    WK = pygame.image.load('images/wk.png').convert_alpha()
    BK = pygame.image.load('images/bk.png').convert_alpha()
    WN = pygame.image.load('images/wn.png').convert_alpha()
    BN = pygame.image.load('images/bn.png').convert_alpha()
    WR = pygame.image.load('images/wr.png').convert_alpha()
    BR = pygame.image.load('images/br.png').convert_alpha()
    WQ = pygame.image.load('images/wq.png').convert_alpha()
    BQ = pygame.image.load('images/bq.png').convert_alpha()
    WB = pygame.image.load('images/wb.png').convert_alpha()
    BB = pygame.image.load('images/bb.png').convert_alpha()
    WP = pygame.image.load('images/wp.png').convert_alpha()
    BP = pygame.image.load('images/bp.png').convert_alpha()

    window.blit(board, (0,0))

    for x in range(0,8):
        for y in range(0,8):
            piece = Board[x][y]
            colCoordinate = x * 61 + 1
            rowCoordinate = y * 61 + 1
        
            if piece == 'BP':
                window.blit(BP, (rowCoordinate, colCoordinate))
            elif piece == 'WP':
                window.blit(WP, (rowCoordinate, colCoordinate))

            elif piece == 'WR':
                window.blit(WR, (rowCoordinate, colCoordinate))
            elif piece == 'WB':
                window.blit(WB, (rowCoordinate, colCoordinate))
            elif piece == 'WN':
                window.blit(WN, (rowCoordinate, colCoordinate))
            elif piece == 'WQ':
                window.blit(WQ, (rowCoordinate, colCoordinate))
            elif piece == 'WK':
                window.blit(WK, (rowCoordinate, colCoordinate))
            elif piece ==  'WN':
                window.blit(WN, (rowCoordinate, colCoordinate))
            elif piece == 'WB':
                window.blit(WB, (rowCoordinate, colCoordinate))
            elif piece == 'WR':
                window.blit(WR, (rowCoordinate, colCoordinate))

            elif piece == 'BR':
                window.blit(BR, (rowCoordinate, colCoordinate))
            elif piece == 'BB':
                window.blit(BB, (rowCoordinate, colCoordinate))
            elif piece == 'BN':
                window.blit(BN, (rowCoordinate, colCoordinate))
            elif piece == 'BQ':
                window.blit(BQ, (rowCoordinate, colCoordinate))
            elif piece == 'BK':
                window.blit(BK, (rowCoordinate, colCoordinate))
            elif piece ==  'BN':
                window.blit(BN, (rowCoordinate, colCoordinate))
            elif piece == 'BB':
                window.blit(BB, (rowCoordinate, colCoordinate))
            elif piece == 'BR':
                window.blit(BR, (rowCoordinate, colCoordinate))



if __name__ == "__main__":
    print("Welcome to Chess!")
    driver()
