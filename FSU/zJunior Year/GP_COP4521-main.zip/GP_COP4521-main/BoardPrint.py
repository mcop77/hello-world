#beginning of the board logic
class Chess_Board:
    def create_board():
        board_x=[]

        for x in range(8):
            board_y =[]
            for y in range(8):

                board_y.append('.')

            board_x.append(board_y)
        board_x[7][7] = 'R'
        board_x[7][6] = 'N'
        board_x[7][5] = 'B'
        board_x[7][4] = 'K'
        board_x[7][3] = 'Q'
        board_x[7][2] = 'B'
        board_x[7][1] = 'N'
        board_x[7][0] = 'R'
        board_x[6][7] = 'P'
        board_x[6][6] = 'P'
        board_x[6][5] = 'P'
        board_x[6][4] = 'P'
        board_x[6][3] = 'P'
        board_x[6][2] = 'P'
        board_x[6][1] = 'P'
        board_x[6][0] = 'P'
        board_x[0][7] = 'R'
        board_x[0][6] = 'N'
        board_x[0][5] = 'B'
        board_x[0][4] = 'K'
        board_x[0][3] = 'Q'
        board_x[0][2] = 'B'
        board_x[0][1] = 'N'
        board_x[0][0] = 'R'
        board_x[1][7] = 'P'
        board_x[1][6] = 'P'
        board_x[1][5] = 'P'
        board_x[1][4] = 'P'
        board_x[1][3] = 'P'
        board_x[1][2] = 'P'
        board_x[1][1] = 'P'
        board_x[1][0] = 'P'

        line = ''

        for x in range(8):
            for y in range(8):
                line += board_x[x][y]
                line += '   '
            print(line + '\n')
            line = ''
        return board_x

if __name__ == '__main__':
    Chess_Board.create_board()
