from board import Chess_Board


class Pieces:
    row = 8
    col = 8
    Board = [['0']*row]*col
    pos = Chess_Board.create_board
    

class WhitePawn(Pieces):
    def print(self):
        print('WP')

    def is_valid_move(self, pos, to):
        if pos == 'WP':
            if to == pos[x + 1][y]:
                return True
            else:
                return False


class WhiteRook(Pieces):
    def print(self):
        print('WR')

    def is_valid_move(self, pos, to):
        if pos == 'WR':
            for n in range(x-8):
                if to == pos[x + n][y]:
                    return True
            for n in range(y-8):
                if to == pos[x][y+n]:
                    return True
        return False

class WhiteKnight(Pieces):
    def print(self):
        print('WN')

    def is_valid_move(self, pos, to):
        if pos== 'WN':
            if to in range([8][8]):
                if to==pos[x+2][y-1]:
                    return True
                elif to==pos[x+2][y+1]:
                    return True
                elif to==pos[x+1][y+2]:
                    return True
                elif to==pos[x+1][y-2]:
                    return True
                elif to==pos[x-1][y-2]:
                    return True
                elif to==pos[x-1][y+2]:
                    return True
                elif to==pos[x-2][y-1]:
                    return True
                elif to==pos[x-2][y+1]:
                    return True

            return False




class WhiteBishop(Pieces):
    def print(self):
        print('WB')

    def is_valid_move(self, pos, to):
        if pos == 'WB':
            if to in range([8][8]):
                for n in range(8):
                    if to == pos[x+n][y+n] or to ==  pos[x-n][y-n]:
                        return True
                    return False

class WhiteQueen(Pieces):
    def print(self):
        print('WQ')

    def is_valid_move(self, pos, to):
        if pos=='WQ':
            if to in range([8][8]):
                for n in range(8):
                    if to == pos[x + n][y + n] or to == pos[x - n][y - n]:
                        return True
                    elif to == pos[x+n][y] or to == pos[x-n][y] or to == pos[x][y+n] or to == pos[x][y-n]:
                        return True

                    return False

class WhiteKing(Pieces):
    def print(self):
        print('WK')

    def is_valid_move(self, pos, to):
        if pos=='WK':
            if to in range([8][8]):
                if to == pos[x + 1][y + 1] or to == pos[x - 1][y - 1]:
                    return True
                elif to == pos[x + 1][y] or to == pos[x - 1][y] or to == pos[x][y + 1] or to == pos[x][y - 1]:
                    return True

                return False

class BlackPawn(Pieces):
    def print(self):
        print('BP')

    def is_valid_move(self, pos, to):
        if pos == 'BP':
            if to == pos[x - 1][y]:
                return True
            else:
                return False


class BlackRook(Pieces):
    def print(self):
        print('BR')

    def is_valid_move(self, pos, to):
        if pos == 'BR':
            for n in range(8-x):
                if to == pos[x - n][y]:
                    return True
            for n in range(8-y):
                if to == pos[x][y+n]:
                    return True
        return False


class BlackKnight(Pieces):
    def print(self):
        print('BN')

    def is_valid_move(self, pos, to):
        if pos == 'BN':
            if to in range([8][8]):
                if to == pos[x + 2][y - 1]:
                    return True
                elif to == pos[x + 2][y + 1]:
                    return True
                elif to == pos[x + 1][y + 2]:
                    return True
                elif to == pos[x + 1][y - 2]:
                    return True
                elif to == pos[x - 1][y - 2]:
                    return True
                elif to == pos[x - 1][y + 2]:
                    return True
                elif to == pos[x - 2][y - 1]:
                    return True
                elif to == pos[x - 2][y + 1]:
                    return True


class BlackBishop(Pieces):
    def print(self):
        print('BB')

    def is_valid_move(self, pos, to):
        if pos == 'BB':
            if to in range([8][8]):
                for n in range(8):
                    if to == pos[x + n][y + n] or to == pos[x - n][y - n]:
                        return True
                    return False


class BlackQueen(Pieces):
    def print(self):
        print('BQ')

    def is_valid_move(self, pos, to):
        if pos == 'BQ':
            if to in range([8][8]):
                for n in range(8):
                    if to == pos[x + n][y + n] or to == pos[x - n][y - n]:
                        return True
                    elif to == pos[x + n][y] or to == pos[x - n][y] or to == pos[x][y + n] or to == pos[x][y - n]:
                        return True

                    return False




class BlackKing(Pieces):
    def print(self):
        print('BK')

    def is_valid_move(self, pos, to):
        if pos == 'BK':
            if to in range([8][8]):
                if to == pos[x + 1][y + 1] or to == pos[x - 1][y - 1]:
                    return True
                elif to == pos[x + 1][y] or to == pos[x - 1][y] or to == pos[x][y + 1] or to == pos[x][y - 1]:
                    return True

                return False



class Empty(Pieces):
    def print(self):
        print(' ')


if __name__ == '__main__':
    whitePawn = WhitePawn()
    whiteRook = WhiteRook()
    whiteKnight = WhiteKnight()
    whiteBishop = WhiteBishop()
    whiteQueen = WhiteQueen()
    whiteKing = WhiteKing()

    blackPawn = BlackPawn()
    blackRook = BlackRook()
    blackKnight = BlackKnight()
    blackBishop = BlackBishop()
    blackQueen = BlackQueen()
    blackKing = BlackKing()

    empty = Empty()

    for x in range(8):
        for y in range(8):
            if x == 0:
                if y == 0:
                    print('8', end='\t')
                    Pieces.Board[x][y] = whiteRook
                    print('WR', end='   ')
                elif y == 1 or y == 6:
                    Pieces.Board[x][y] = whiteKnight
                    print('WN', end='   ')
                elif y == 2 or y == 5:
                    Pieces.Board[x][y] = whiteBishop
                    print('WB', end='   ')
                elif y == 3:
                    Pieces.Board[x][y] = whiteQueen
                    print('WQ', end='   ')
                elif y == 4:
                    Pieces.Board[x][y] = whiteKing
                    print('WK', end='   ')
                elif y == 5:
                    Pieces.Board[x][y] = whiteKing
                    print('WK', end='   ')
                elif y == 6:
                    Pieces.Board[x][y] = whiteKing
                    print('WK', end='   ')
                elif y == 7:
                    Pieces.Board[x][y] = whiteKing
                    print('WK', end='   ')
                    print('\n')
            elif x == 1:
                if y == 0:
                    print('7', end='\t')
                Pieces.Board[x][y] = whitePawn
                print('WP', end='   ')
                if y == 7:
                    print('\n')
            elif x == 2:
                if y == 0:
                    print('6', end='\t')
                Pieces.Board[x][y] = empty
                print('0', end='    ')
                if y == 7:
                    print('\n')
            elif x == 3:
                if y == 0:
                    print('5', end='\t')
                Pieces.Board[x][y] = empty
                print('0', end='    ')
                if y == 7:
                    print('\n')
            elif x == 4:
                if y == 0:
                    print('4', end='\t')
                Pieces.Board[x][y] = empty
                print('0', end='    ')
                if y == 7:
                    print('\n')
            elif x == 5:
                if y == 0:
                    print('3', end='\t')
                Pieces.Board[x][y] = empty
                print('0', end='    ')
                if y == 7:
                    print('\n')
            elif x == 6:
                if y == 0:
                    print('2', end='\t')
                Pieces.Board[x][y] = blackPawn
                print('BP', end='   ')
                if y == 7:
                    print('\n')
            elif x == 7:
                if y == 0:
                    print('1', end='\t')
                    Pieces.Board[x][y] = whiteRook
                    print('WR', end='   ')
                elif y == 1 or y == 6:
                    Pieces.Board[x][y] = whiteKnight
                    print('WN', end='   ')
                elif y == 2 or y == 5:
                    Pieces.Board[x][y] = whiteBishop
                    print('WB', end='   ')
                elif y == 3:
                    Pieces.Board[x][y] = whiteQueen
                    print('WQ', end='   ')
                elif y == 4:
                    Pieces.Board[x][y] = whiteKing
                    print('WK', end='   ')
                elif y == 5:
                    Pieces.Board[x][y] = whiteKing
                    print('WK', end='   ')
                elif y == 6:
                    Pieces.Board[x][y] = whiteKing
                    print('WK', end='   ')
                elif y == 7:
                    Pieces.Board[x][y] = whiteKing
                    print('WK', end='   ')
                    print('\n')
print(
    ' ' + '\t' + 'A' + '    ' + 'B' + '    ' + 'C' + '    ' + 'D' + '    ' + 'E' + '    ' 'F' + '    ' + 'G' + '    ' + 'H' + '    ')
