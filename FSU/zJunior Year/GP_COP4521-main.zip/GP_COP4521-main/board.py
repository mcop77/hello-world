#beginning of the board logic
class Chess_Board:
    def __init__(self):
        self.board = self.create_board()

    def create_board(self):
        board_x=[]

        for x in range(8):
            board_y =[]
            for y in range(8):

                board_y.append('.')
            board_x.append(board_y)
        board_x[7][7] = 'WR'
        board_x[7][6] = 'WN'
        board_x[7][5] = 'WB'
        board_x[7][4] = 'WK'
        board_x[7][3] = 'WQ'
        board_x[7][2] = 'WB'
        board_x[7][1] = 'WN'
        board_x[7][0] = 'WR'
        board_x[6][7] = 'WP'
        board_x[6][6] = 'WP'
        board_x[6][5] = 'WP'
        board_x[6][4] = 'WP'
        board_x[6][3] = 'WP'
        board_x[6][2] = 'WP'
        board_x[6][1] = 'WP'
        board_x[6][0] = 'WP'
        board_x[0][7] = 'BR'
        board_x[0][6] = 'BN'
        board_x[0][5] = 'BB'
        board_x[0][4] = 'BK'
        board_x[0][3] = 'BQ'
        board_x[0][2] = 'BB'
        board_x[0][1] = 'BN'
        board_x[0][0] = 'BR'
        board_x[1][7] = 'BP'
        board_x[1][6] = 'BP'
        board_x[1][5] = 'BP'
        board_x[1][4] = 'BP'
        board_x[1][3] = 'BP'
        board_x[1][2] = 'BP'
        board_x[1][1] = 'BP'
        board_x[1][0] = 'BP'
        return board_x